-- SQL to aggregate churn-related metrics
SELECT customer_id, SUM(call_duration), COUNT(complaints), AVG(recharge_amount) FROM telecom_data GROUP BY customer_id;