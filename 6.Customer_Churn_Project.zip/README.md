# Customer Churn Analysis for Telecom Industry

This project predicts customer churn using machine learning and provides retention strategies.