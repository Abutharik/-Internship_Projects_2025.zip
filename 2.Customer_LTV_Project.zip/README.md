# Customer Lifetime Value Prediction Model

This project uses transaction data to predict CLTV using XGBoost.