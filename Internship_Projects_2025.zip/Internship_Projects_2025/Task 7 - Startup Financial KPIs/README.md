# Task 7 - Startup Financial KPIs

> Project files go here.
