# Movie Success Prediction and Sentiment Study

## Overview
This project aims to analyze movie data and predict whether a movie will be a success based on various features such as budget, revenue, ratings, and sentiment of reviews.

## Dataset
The dataset contains information on 200 movies including:
- Title, Year, Genre
- Budget, Revenue
- IMDB Rating, Rotten Tomatoes Score
- Sentiment of reviews (positive, neutral, negative)

## Steps:
1. Data Cleaning
2. EDA (Exploratory Data Analysis)
3. Sentiment Impact Analysis
4. Predictive Modeling (Success = Revenue > Budget)

## Libraries Used
- Pandas
- NumPy
- Seaborn / Matplotlib
- Scikit-learn
- NLTK / TextBlob (for sentiment analysis)

## How to Run
Run the `Movie_Success_Analysis.ipynb` file in Jupyter Notebook to see the analysis, model building, and results.

## Author
A. Mohammed Ismail
