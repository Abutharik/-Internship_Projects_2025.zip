# E-commerce Return Rate Reduction Analysis

This project identifies high-risk products using logistic regression and visualizes insights using Power BI.