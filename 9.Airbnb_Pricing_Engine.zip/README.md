# Airbnb Dynamic Pricing Recommendation Engine

This project analyzes Airbnb NYC data and predicts optimal listing prices using machine learning.