
# Real-Time Twitter/X Sentiment Dashboard

This project provides a simple real-time sentiment analysis dashboard using Twitter/X data.

## Features
- Scrapes live tweets using `snscrape`
- Analyzes sentiment using `VADER`
- Displays pie chart, word cloud, and time-series of tweet activity using Streamlit

## How to Run

```bash
pip install -r requirements.txt
python tweet_sentiment_analysis.py
streamlit run app.py
```

## Output
- `tweets_sentiment.csv`: contains the tweet data and sentiments
