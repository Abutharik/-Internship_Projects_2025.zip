
import snscrape.modules.twitter as sntwitter
import pandas as pd
import nltk
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from datetime import datetime
import re

# Download NLTK data
nltk.download('vader_lexicon')

# Function to clean tweet text
def clean_tweet(tweet):
    tweet = re.sub(r"http\S+|www\S+|https\S+", '', tweet, flags=re.MULTILINE)
    tweet = re.sub(r'\@\w+|\#','', tweet)
    return tweet.strip()

# Initialize sentiment analyzer
analyzer = SentimentIntensityAnalyzer()

# Keyword to search
query = "technology"

# Collect tweets (limit to 100 for demo)
tweets = []
for i, tweet in enumerate(sntwitter.TwitterSearchScraper(f'{query} lang:en').get_items()):
    if i > 100:
        break
    cleaned = clean_tweet(tweet.content)
    sentiment_score = analyzer.polarity_scores(cleaned)
    sentiment = 'Positive' if sentiment_score['compound'] > 0.05 else 'Negative' if sentiment_score['compound'] < -0.05 else 'Neutral'
    tweets.append([tweet.date, tweet.user.username, cleaned, sentiment])

# Save to CSV
df = pd.DataFrame(tweets, columns=['Date', 'User', 'Tweet', 'Sentiment'])
df['Date'] = pd.to_datetime(df['Date'])
df.to_csv("tweets_sentiment.csv", index=False)
print("Saved tweets_sentiment.csv")
