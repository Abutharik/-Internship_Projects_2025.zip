
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from wordcloud import WordCloud

# Load data
df = pd.read_csv("tweets_sentiment.csv")
st.title("Twitter/X Real-Time Sentiment Dashboard")
st.markdown("## Keyword: Technology (Demo)")

# Sentiment Count
sentiment_counts = df['Sentiment'].value_counts()
st.subheader("Sentiment Distribution")
st.bar_chart(sentiment_counts)

# Word Cloud
st.subheader("Word Cloud")
all_words = ' '.join(df['Tweet'])
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(all_words)
st.image(wordcloud.to_array())

# Time-series chart (Tweets over time)
st.subheader("Tweet Frequency Over Time")
df['Date'] = pd.to_datetime(df['Date'])
df.set_index('Date', inplace=True)
st.line_chart(df.resample('H').size())
