-- SQL to rank categories by average views
SELECT category, AVG(views) AS avg_views FROM trending_videos GROUP BY category ORDER BY avg_views DESC;