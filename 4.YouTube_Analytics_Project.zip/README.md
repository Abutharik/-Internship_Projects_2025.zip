# YouTube Trending Video Analytics

This project analyzes YouTube trending videos using Python, SQL, and Tableau. Includes sentiment analysis and category trends.